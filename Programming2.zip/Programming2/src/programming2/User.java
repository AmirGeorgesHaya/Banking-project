/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;

/**
 *
 * @author École
 */
public class User {
    BankAccount bankAccount;
    Checking checking;
    Savings savings;
   public int accountNumber;
   private int pinCode;
   
   public User( int accountNumber, int pinCode, Checking checking, Savings savings){
      
       this.accountNumber=accountNumber;
       this.pinCode=pinCode;
       this.checking=checking;
       this.savings=savings;
   }

    public Checking getChecking() {
        return checking;
    }

    public void setChecking(Checking checking) {
        this.checking = checking;
    }

    public Savings getSavings() {
        return savings;
    }

    public void setSavings(Savings savings) {
        this.savings = savings;
    }

   

    public int getAccountNumber() {
        return accountNumber;
    }

    public int getPinCode() {
        return pinCode;
    }


    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }
    boolean authenticate(int pinAttempt) {
        return pinCode == pinAttempt;
    }

    
}
