/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;

import java.util.HashMap;

/**
 *
 * @author École
 */
public abstract class BankAccount {
    public double balance;
public int  accountNumber;
    /**
     * Constructor to initialize the account with an account number and balance
     * @param accountNumber will be used to validate someone
     * @param balance The sum of money he poseses
     */
    public BankAccount(int accountNumber, double balance) {
        this.balance = balance;
        this.accountNumber = accountNumber;
    }

    public double getAccountMoney() {
        return balance;
    }

    public void setAccountMoney(double balance) {
        this.balance = balance;
    }

    //Abstract method that will be implemented by the subclass Savings and Checking
    abstract boolean withdraw(double amount);
    
    
    
    
    
}
