/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;

/**
 *
 * @author École
 */
public class Savings extends BankAccount{

      public Savings(int accountNumber, double balance) {
        super( accountNumber,  balance);
    }
    @Override
         // Checks if the balance has enough money and prints the result on the console
    // JavaFX will print it on the Alert banner
 boolean withdraw(double amount) {
        if (balance - amount >= 0) {
            balance -= amount;
            System.out.println("Savings Account: Withdrawal of $" + amount + " successful. New balance: $" + balance);
            return true;  // Withdrawal successful
        } else {
            System.out.println("Savings Account: Insufficient funds.");
            return false;  // Insufficient funds
        }
    }

}

