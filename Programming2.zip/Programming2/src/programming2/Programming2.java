/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programming2;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author École
 */
public class Programming2 extends Application {

    private ArrayList<User> users;
   

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Initialize users and accounts
        users = new ArrayList<>();
     Checking   checkingAccount = new Checking(123456789, 1000);
       Savings  savingsAccount = new Savings(123456789, 500);

        User user = new User(123456789, 1234, checkingAccount, savingsAccount);
 users.add(user);
 
 
       Checking checkingAccount2 = new Checking(1234567891, 30);
       Savings savingsAccount2 = new Savings(1234567891, 250);

        User user2 = new User(1234567891, 12345, checkingAccount2, savingsAccount2);
        // adds user to the ArrayList
        users.add(user2);

        // Create the login screen
        // Name of the login screen
        primaryStage.setTitle("Banking Application - Login");

        // center everything in the middle
        VBox loginBox = new VBox(10);
        loginBox.setAlignment(Pos.CENTER);
        loginBox.setPadding(new Insets(25));

        // Title login
        Label titleLabel = new Label("Login to Banking Application");
        //Making the title bold and big
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        // creates two text fields that have a prompt text
        // showing the user what data goes where
        TextField accountNumberField = new TextField();
        accountNumberField.setPromptText("Account Number");

        PasswordField pinField = new PasswordField();
        pinField.setPromptText("PIN");

        // Create the button and when pressed, it goes through the validate ID
        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> {
            try {
                //Converts the string numbers of account number and pin from the text fields of Login
                // to Int
                int accountNumber = Integer.parseInt(accountNumberField.getText());
                int pin = Integer.parseInt(pinField.getText());
// Calls the authenticate user to see if it is correct
                User currentUser = authenticateUser(accountNumber, pin);

                //If login is correct, it will show you which account the user wants to log into
                if (currentUser != null) {
                    showAccountSelectionScreen(primaryStage, currentUser);
                }// if login is incorrect, then the return is NUll which fails the authentication 
                else {
                    showAlert("Authentication Failed", "Invalid account number or PIN.");
                }
            } catch (NumberFormatException ex) {
                showAlert("Invalid Input", "Please enter valid numerical values.");
            }
        });

        loginBox.getChildren().addAll(titleLabel, accountNumberField, pinField, loginButton);

        Scene scene = new Scene(loginBox, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
/**
 * Authenticate the user by looking at the account number and pin
 * @param accountNumber
 * @param pin
 * @return returns the user if the authentication is correct and Null if incorrect
 */
    private User authenticateUser(int accountNumber, int pin) {
        // Goes through an arrayList to find if the user is correct
        for (User user : users) {
            //cif the authenticate method from the User class  and account numbers are equal (then true)
            // return User and if not return NULL to fail the authenticator
            if (user.authenticate(pin) && user.getAccountNumber() == accountNumber) {
                return user;
            }
        }
        return null;
    }
/**
 * Displays the account selection screen
 * @param primaryStage
 * @param user the authenticated user
 */
    private void showAccountSelectionScreen(Stage primaryStage, User currentUser) {
        // To make sure the code is correctly transitioning to the new stage
        System.out.println("Entering showAccountSelectionScreen");

        // Create the account selection screen
        VBox selectionBox = new VBox(10);
        selectionBox.setAlignment(Pos.CENTER);
        selectionBox.setPadding(new Insets(20));

        Label welcomeLabel = new Label("Welcome, Account Number: " + currentUser.getAccountNumber() + "!");
        welcomeLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
// Creates 2 button: one for checking and one for saving
        Button checkingButton = new Button("Checking Account");
        checkingButton.setOnAction(e -> showWithdrawalScreen(primaryStage, currentUser.getChecking()));

        Button savingsButton = new Button("Savings Account");
        savingsButton.setOnAction(e -> showWithdrawalScreen(primaryStage, currentUser.getSavings()));

        selectionBox.getChildren().addAll(welcomeLabel, checkingButton, savingsButton);

        Scene scene = new Scene(selectionBox, 400, 200);
        primaryStage.setScene(scene);

        // Print another debug statement to verify that the scene has been set
        System.out.println("Exiting showAccountSelectionScreen");
    }
/**
 * displays the withdrawal screen
 * @param primaryStage 
 * @param account the selected account for withdrawal
 */
    private void showWithdrawalScreen(Stage primaryStage, BankAccount account) {
        // Create the withdrawal screen
               System.out.println("entering showWithdrawal");

        VBox withdrawalBox = new VBox(10);
        withdrawalBox.setAlignment(Pos.CENTER);
        withdrawalBox.setPadding(new Insets(20));

        Label titleLabel = new Label("Withdrawal Screen");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField amountField = new TextField();
        amountField.setPromptText("Enter withdrawal amount");

        Button withdrawButton = new Button("Withdraw");
        withdrawButton.setOnAction(e -> {
            try {
                double amount = Double.parseDouble(amountField.getText());
                boolean withdrawalSuccessful = ATM.performWithdrawal(account, amount);

                if (withdrawalSuccessful) {
                    showAlert("Withdrawal Successful", "Withdrawal of $" + amount + " successful. New balance: $" + account.balance);
                } else {
                    showAlert("Insufficient Funds", "Insufficient funds for withdrawal of $" + amount);
                }
            } catch (NumberFormatException ex) {
                showAlert("Invalid Amount", "Please enter a valid numerical amount.");
            }
        });

        Button backToSelectionButton = new Button("Back to Account Selection");
        backToSelectionButton.setOnAction(e -> showAccountSelectionScreen(primaryStage, users.get(0)));

        withdrawalBox.getChildren().addAll(titleLabel, amountField, withdrawButton, backToSelectionButton);

        Scene scene = new Scene(withdrawalBox, 400, 200);
        primaryStage.setScene(scene);
    }
/**
 * Displays an alert showing the user if the transaction was successful
 * @param title title of the alert
 * @param message Message of the alert
 */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
