/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;

/**
 *
 * @author École
 */
class ATM {
    // calls the withdraw methods from Savings and Checking and returns true or false in the main class
    static boolean performWithdrawal(BankAccount account, double amount) {
       return account.withdraw(amount);
    }
}
