/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;

/**
 *The ATM is used to to call the account and check the amount asked from the user 
 * is possible to withdraw from the balance
 * @author École
 */
class ATM {
    /**
     * The main class calls this method in the Atm.
     * This atm calls the account to check whether the withdrawal is possible 
     * @param account account of Savings or Checking
     * @param amount the amount to reduce from ATM
     * @return returns true or false to the Main class
     */
    static boolean performWithdrawal(BankAccount account, double amount) {
       return account.withdraw(amount);
    }
}
