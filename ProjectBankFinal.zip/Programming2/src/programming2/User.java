/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;

/**
 *The client that has a savings and checking account
 * This client has an account number and pincode to safely log in
 * 
 * @author École
 */
public class User {
    BankAccount bankAccount;
    Checking checking;
    Savings savings;
   public int accountNumber;
   private int pinCode;
   /**
    * Creates the user and links the user to a checking and savings account
    * @param accountNumber account number of the user
    * @param pinCode the password of the account
    * @param checking the checking account of the user (has a different balance than savings)
    * @param savings the savings account of the user (has a different balance than checking)
    */
   public User( int accountNumber, int pinCode, Checking checking, Savings savings){
      
       this.accountNumber=accountNumber;
       this.pinCode=pinCode;
       this.checking=checking;
       this.savings=savings;
   }

   /**
    * gets the checking Object
    * @return the checking Object
    */
    public Checking getChecking() {
        return checking;
    }
/**
 * Set the checking account Object for the user
 * @param checking checking account object
 */
    public void setChecking(Checking checking) {
        this.checking = checking;
    }
/**
 * gets the savings account 
 * @return savings account object
 */
    public Savings getSavings() {
        return savings;
    }
/**
 * Sets the saving account Object
 * @param savings saving account object
 */
    public void setSavings(Savings savings) {
        this.savings = savings;
    }

   
/**
 * Gets the user account number
 * @return returns the account number of the user
 */
    public int getAccountNumber() {
        return accountNumber;
    }
/**
 * gets the pin code for the user
 * @return returns pinCode of the user
 */
    public int getPinCode() {
        return pinCode;
    }

/** 
 * set the account number for the user
 * @param accountNumber account Number of the User
 */
    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
/**
 * Set the pinCode of the user
 * @param pinCode pin code of the user
 */
    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }
    /**
     * Authenticates the pinCode whether the pin code written is equal to the User's
     * @param pinAttempt pin code written by the client
     * @return returns true or false depending on if the pin code written by the client is equal to the User's pin
     */
    boolean authenticate(int pinAttempt) {
        return pinCode == pinAttempt;
    }

    
}
