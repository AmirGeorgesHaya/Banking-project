/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package programming2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author École
 */
public class UserTest {
     Checking checking;
    Savings savings;
    public UserTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

   



  

    /**
     * Test of authenticate method, of class User.
     */
    @Test
    public void testAuthenticate() {
        System.out.println("authenticate");

        // Create instances of Checking and Savings
        Checking checking = new Checking(123456789, 1000);
        Savings savings = new Savings(987654321, 500);

        // Create a User instance with valid checking and savings accounts
        User instance = new User(123456789, 1234, checking, savings);

        // Set the correct pin attempt
        int pinAttempt = 1234;

        // Test the authenticate method
        boolean expResult = true;
        boolean result = instance.authenticate(pinAttempt);

        assertEquals(expResult, result);
    }
}
