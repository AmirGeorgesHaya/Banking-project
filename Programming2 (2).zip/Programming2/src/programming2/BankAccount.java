/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;


/**
 *An abstract class that encapsulates the properties of savings account and checking account
 * @author École
 */
public abstract class BankAccount {
    
    /**
     * 
     */
    public double balance;
public int  accountNumber;
    /**
     * Constructor to initialize the account with an account number and balance
     * @param accountNumber will be used to validate a client
     * @param balance the balance the user posses in his accounts
     */
    public BankAccount(int accountNumber, double balance) {
        this.balance = balance;
        this.accountNumber = accountNumber;
    }
/**
 * retrieves the balance of the account
 * @return returns balance of the account
 */
    public double getAccountMoney() {
        return balance;
    }
/**
 * sets the balance of an account
 * @param balance balance of an account
 */
    public void setAccountMoney(double balance) {
        this.balance = balance;
    }
/**
 * Abstract method that will be implemented by the subclass Savings and Checking
 * @param amount the amount that will be withdrawn from the balance
 * @return an abstract class doesn't have a return (check savings and checkings acccount)
 */
    
    abstract boolean withdraw(double amount);
    
    
    
    
    
}
