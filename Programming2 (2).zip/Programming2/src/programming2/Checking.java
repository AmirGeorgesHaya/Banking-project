/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package programming2;
/**
 *The checking account extends the BankAccount object 
 * Checking account is an account that has a balance like the Savings account
 * @author École
 */
public class Checking extends BankAccount{

    public Checking(int accountNumber, double balance) {
        super( accountNumber,  balance);
    }
     /**
       * Checks if the balance has enough money and prints the result on the console
       * JavaFX will print it on the Alert banner
       * @param amount the amount to be reduce of  the balance
       * @return returns a true or false for the ATM
       */
    @Override
    
 boolean withdraw(double amount) {
        if (balance - amount >= 0) {
           // Withdrawal successfull
            balance -= amount;
            System.out.println("Savings Account: Withdrawal of $" + amount + " successful. New balance: $" + balance);
            return true;  
        } else {
            //Withdrawal unsuccessfull
            System.out.println("Savings Account: Insufficient funds.");
            return false;  
        }
    }

}

    
   

